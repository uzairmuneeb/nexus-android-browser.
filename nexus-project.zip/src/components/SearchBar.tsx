import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { buildUrl, type Engine } from "../lib/engines";
import { fetchSuggestions, localSuggestions } from "../lib/suggest";
import { useDebounced } from "../lib/hooks";

type Props = {
  query: string;
  onQueryChange: (q: string) => void;
  engine: Engine;
  engines: Engine[];
  onEngineChange: (e: Engine) => void;
  onSubmit: (q: string, engine: Engine, opts?: { lucky?: boolean; forceNewTab?: boolean }) => void;
  history: string[];
  trending: string[];
  onNotify: (msg: string, tone?: "info" | "error" | "success") => void;
  compact?: boolean;
  autoFocusKey?: number;
};

export default function SearchBar({
  query,
  onQueryChange,
  engine,
  engines,
  onEngineChange,
  onSubmit,
  history,
  trending,
  onNotify,
  compact,
  autoFocusKey,
}: Props) {
  const [open, setOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [live, setLive] = useState(false);
  const [active, setActive] = useState(-1);
  const [engineMenu, setEngineMenu] = useState(false);
  const [listening, setListening] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const debounced = useDebounced(query, 200);

  /* ---------------- suggestions ---------------- */
  useEffect(() => {
    let alive = true;
    if (!debounced.trim()) {
      setSuggestions(trending.slice(0, 6));
      setLive(false);
      return;
    }
    fetchSuggestions(debounced, history, trending).then(({ list, live }) => {
      if (!alive) return;
      setSuggestions(list.length ? list : localSuggestions(debounced, history, trending));
      setLive(live);
    });
    return () => {
      alive = false;
    };
  }, [debounced, history, trending]);

  /* ---------------- focus + shortcuts ---------------- */
  useEffect(() => {
    if (autoFocusKey) inputRef.current?.focus();
  }, [autoFocusKey]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typingElsewhere = target && /^(input|textarea)$/i.test(target.tagName) && target !== inputRef.current;
      if ((e.key === "k" && (e.metaKey || e.ctrlKey)) || (e.key === "/" && !typingElsewhere)) {
        e.preventDefault();
        inputRef.current?.focus();
        inputRef.current?.select();
        setOpen(true);
      }
      if (e.key === "Escape") {
        setOpen(false);
        setEngineMenu(false);
        inputRef.current?.blur();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) {
        setOpen(false);
        setEngineMenu(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const items = useMemo(() => {
    const base = suggestions.slice(0, 8);
    return query.trim() && !base.some((s) => s.toLowerCase() === query.trim().toLowerCase())
      ? [...base, query.trim()]
      : base;
  }, [suggestions, query]);

  const choose = (value: string) => {
    setOpen(false);
    setActive(-1);
    onQueryChange(value);
    onSubmit(value, engine);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setActive((i) => (items.length ? (i + 1) % items.length : -1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((i) => (items.length ? (i - 1 + items.length) % items.length : -1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (active >= 0 && items[active]) {
        choose(items[active]);
      } else {
        setOpen(false);
        onSubmit(query, engine, { forceNewTab: e.metaKey || e.ctrlKey });
      }
    } else if (e.key === "Tab" && open && items[0]) {
      e.preventDefault();
      onQueryChange(items[active >= 0 ? active : 0]);
    }
  };

  /* ---------------- voice search ---------------- */
  const startVoice = () => {
    const SR =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike })
        .SpeechRecognition ??
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike }).webkitSpeechRecognition;
    if (!SR) {
      onNotify("Voice search isn’t supported in this browser.", "error");
      return;
    }
    const rec = new SR();
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onstart = () => setListening(true);
    rec.onerror = () => {
      setListening(false);
      onNotify("Microphone unavailable or permission denied.", "error");
    };
    rec.onend = () => setListening(false);
    rec.onresult = (event) => {
      const text = event.results?.[0]?.[0]?.transcript;
      if (text) {
        onQueryChange(text);
        setOpen(false);
        onSubmit(text, engine);
      }
    };
    rec.start();
  };

  const showDrop = open && (items.length > 0 || engineMenu);

  return (
    <div ref={wrapRef} className="relative w-full">
      <div
        className={cn(
          "group relative flex items-center gap-1 rounded-full border bg-white/85 shadow-xl transition-all duration-300",
          "border-slate-200/90 shadow-slate-900/5 dark:border-white/12 dark:bg-white/[0.06] dark:shadow-black/40",
          "backdrop-blur-xl",
          !compact && "px-2 py-2",
          compact && "px-1.5 py-1.5",
          open ? "border-indigo-300 shadow-indigo-500/15 dark:border-indigo-400/40" : "hover:border-slate-300",
        )}
      >
        {/* engine selector */}
        <div className="relative shrink-0">
          <button
            onClick={() => {
              setEngineMenu((v) => !v);
              setOpen(true);
            }}
            title={`Searching with ${engine.name}`}
            className={cn(
              "flex items-center gap-2 rounded-full transition",
              compact ? "px-2 py-1.5" : "px-3 py-2",
              "hover:bg-slate-900/5 dark:hover:bg-white/10",
            )}
          >
            <span
              className={cn(
                "grid place-items-center rounded-lg bg-gradient-to-br text-[13px] font-bold text-white shadow-sm",
                engine.accent,
                compact ? "h-6 w-6" : "h-7 w-7",
              )}
            >
              {engine.icon}
            </span>
            {!compact && (
              <span className="hidden text-sm font-medium text-slate-700 sm:block dark:text-slate-200">
                {engine.name}
              </span>
            )}
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-slate-400" fill="none" stroke="currentColor" strokeWidth={2.5}>
              <path d="m6 9 6 6 6-6" strokeLinecap="round" />
            </svg>
          </button>

          {engineMenu && showDrop && (
            <div className="animate-pop absolute top-full left-0 z-40 mt-2 max-h-80 w-72 overflow-y-auto rounded-2xl border border-slate-200/80 bg-white/95 p-2 shadow-2xl shadow-slate-900/10 backdrop-blur-xl dark:border-white/10 dark:bg-ink-800/95">
              {engines.map((e) => (
                <button
                  key={e.id}
                  onClick={() => {
                    onEngineChange(e);
                    setEngineMenu(false);
                    inputRef.current?.focus();
                  }}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition",
                    e.id === engine.id ? "bg-indigo-500/10" : "hover:bg-slate-100 dark:hover:bg-white/8",
                  )}
                >
                  <span className={cn("grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-gradient-to-br text-[13px] font-bold text-white", e.accent)}>
                    {e.icon}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium text-slate-800 dark:text-slate-100">{e.name}</span>
                    <span className="block truncate text-[11px] text-slate-400">{e.hint}</span>
                  </span>
                  {e.id === engine.id && (
                    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-indigo-500" fill="none" stroke="currentColor" strokeWidth={3}>
                      <path d="m5 13 4 4L19 7" strokeLinecap="round" />
                    </svg>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        <span className="h-6 w-px shrink-0 bg-slate-200 dark:bg-white/10" />

        {/* input */}
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            onQueryChange(e.target.value);
            setOpen(true);
            setActive(-1);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={`Search ${engine.name} or type a URL…`}
          spellCheck={false}
          autoComplete="off"
          aria-label="Search query"
          className={cn(
            "min-w-0 flex-1 bg-transparent font-sans text-slate-900 placeholder-slate-400 outline-none dark:text-white dark:placeholder-slate-500",
            compact ? "px-2 py-1.5 text-[15px]" : "px-3 py-2 text-base sm:text-[17px]",
          )}
        />

        {query && (
          <button
            onClick={() => {
              onQueryChange("");
              inputRef.current?.focus();
            }}
            aria-label="Clear"
            className="shrink-0 rounded-full p-2 text-slate-400 transition hover:bg-slate-900/5 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-white"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.2}>
              <path d="M18 6 6 18M6 6l12 12" strokeLinecap="round" />
            </svg>
          </button>
        )}

        <button
          onClick={startVoice}
          title="Voice search"
          aria-label="Voice search"
          className={cn(
            "shrink-0 rounded-full p-2.5 transition",
            listening
              ? "bg-rose-500/15 text-rose-500"
              : "text-slate-400 hover:bg-slate-900/5 hover:text-indigo-500 dark:hover:bg-white/10",
          )}
        >
          <svg viewBox="0 0 24 24" className={cn("h-4 w-4", listening && "animate-pulse")} fill="none" stroke="currentColor" strokeWidth={2}>
            <rect x="9" y="3" width="6" height="11" rx="3" />
            <path d="M5 11a7 7 0 0 0 14 0M12 18v3" strokeLinecap="round" />
          </svg>
        </button>

        <button
          onClick={() => onSubmit(query, engine)}
          disabled={!query.trim()}
          aria-label="Search"
          className={cn(
            "grid shrink-0 place-items-center rounded-full bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-40",
            compact ? "h-9 w-9" : "h-10 w-10",
          )}
        >
          <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={2.4}>
            <circle cx="11" cy="11" r="6.5" />
            <path d="m16 16 4.5 4.5" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {/* suggestions */}
      {open && !engineMenu && items.length > 0 && (
        <div className="animate-pop absolute inset-x-0 top-full z-30 mt-2 overflow-hidden rounded-2xl border border-slate-200/80 bg-white/95 shadow-2xl shadow-slate-900/10 backdrop-blur-xl dark:border-white/10 dark:bg-ink-800/95">
          <ul className="p-1.5">
            {items.map((s, i) => (
              <li key={s + i}>
                <button
                  onMouseEnter={() => setActive(i)}
                  onClick={() => choose(s)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[15px] transition",
                    i === active
                      ? "bg-indigo-500/10 text-slate-900 dark:text-white"
                      : "text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/8",
                  )}
                >
                  <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-slate-400" fill="none" stroke="currentColor" strokeWidth={2}>
                    <circle cx="11" cy="11" r="6.5" />
                    <path d="m16 16 4.5 4.5" strokeLinecap="round" />
                  </svg>
                  <span className="truncate">{s}</span>
                  {history.includes(s) && (
                    <span className="ml-auto shrink-0 text-[10px] tracking-wide text-slate-400 uppercase">history</span>
                  )}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex items-center justify-between border-t border-slate-200/70 px-4 py-2 text-[11px] text-slate-400 dark:border-white/10">
            <span>{live ? "Live Google suggestions" : "Offline suggestions"}</span>
            <span className="hidden items-center gap-3 sm:flex">
              <kbd className="rounded border border-slate-300 px-1.5 py-0.5 font-sans dark:border-white/15">↑↓</kbd>
              navigate
              <kbd className="rounded border border-slate-300 px-1.5 py-0.5 font-sans dark:border-white/15">⇥</kbd>
              fill
              <kbd className="rounded border border-slate-300 px-1.5 py-0.5 font-sans dark:border-white/15">⏎</kbd>
              {engine.name}
            </span>
          </div>
        </div>
      )}

      {/* action buttons (hero only) */}
      {!compact && (
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => onSubmit(query, engine)}
            className="rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 px-6 py-3 text-[15px] font-medium text-white shadow-lg shadow-indigo-500/25 transition hover:-translate-y-0.5 hover:shadow-indigo-500/40 active:translate-y-0"
          >
            Search {engine.name}
          </button>
          <button
            onClick={() => onSubmit(query, engine, { lucky: true })}
            className="rounded-xl border border-slate-300/80 bg-white/70 px-6 py-3 text-[15px] font-medium text-slate-700 transition hover:-translate-y-0.5 hover:border-slate-400 hover:bg-white dark:border-white/15 dark:bg-white/5 dark:text-slate-200 dark:hover:bg-white/10"
          >
            I’m Feeling Lucky
          </button>
          {engine.lucky && (
            <span className="w-full text-center text-xs text-slate-400 sm:w-auto">
              Opens <span className="text-slate-500 dark:text-slate-300">{buildUrl(engine, query || "google")}</span>
            </span>
          )}
        </div>
      )}
    </div>
  );
}

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  onresult: ((event: { results?: { [index: number]: { [index: number]: { transcript: string } } } }) => void) | null;
};
