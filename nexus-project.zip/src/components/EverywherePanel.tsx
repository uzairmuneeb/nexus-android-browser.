import { cn } from "../utils/cn";
import { buildUrl, hostOf, type Engine } from "../lib/engines";
import { Button } from "./ui";

export default function EverywherePanel({
  query,
  engines,
  selected,
  onToggle,
  onRun,
  onNotify,
}: {
  query: string;
  engines: Engine[];
  selected: string[];
  onToggle: (ids: string[]) => void;
  onRun: (q: string, engine: Engine) => void;
  onNotify: (msg: string, tone?: "info" | "error" | "success") => void;
}) {
  const q = query.trim() || "google";
  const targets = engines.filter((e) => selected.includes(e.id));

  const openAll = async () => {
    if (targets.length === 0) return;
    for (const e of targets) {
      window.open(buildUrl(e, q), "_blank", "noopener,noreferrer");
      await new Promise((r) => setTimeout(r, 160));
    }
    onNotify(`Opened ${targets.length} tab${targets.length === 1 ? "" : "s"}`, "success");
  };

  const copyAll = async () => {
    const text = targets.map((e) => `${e.name}: ${buildUrl(e, q)}`).join("\n");
    try {
      await navigator.clipboard.writeText(text);
      onNotify("Copied all search URLs", "success");
    } catch {
      onNotify("Clipboard blocked by the browser", "error");
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-slate-200/80 bg-gradient-to-br from-indigo-500/5 via-transparent to-blue-500/5 p-6 dark:border-white/10">
        <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">Search everywhere at once</h3>
        <p className="mt-1 max-w-2xl text-sm leading-relaxed text-slate-600 dark:text-slate-300">
          Fire <span className="font-semibold text-slate-800 dark:text-slate-100">“{q}”</span> across{" "}
          {targets.length || engines.length} engines simultaneously. Select the ones you want, then launch them as tabs
          in one go.
        </p>

        <div className="mt-5 flex flex-wrap gap-2">
          {engines.map((e) => {
            const on = selected.includes(e.id);
            return (
              <button
                key={e.id}
                onClick={() => onToggle(on ? selected.filter((id) => id !== e.id) : [...selected, e.id])}
                className={cn(
                  "flex items-center gap-2 rounded-full border px-3 py-1.5 text-[13px] font-medium transition",
                  on
                    ? "border-indigo-400/60 bg-indigo-500/12 text-indigo-600 dark:text-indigo-300"
                    : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:text-slate-400",
                )}
              >
                <span className={cn("grid h-5 w-5 place-items-center rounded-md bg-gradient-to-br text-[10px] font-bold text-white", e.accent)}>
                  {e.icon}
                </span>
                {e.name}
                {on && <span className="text-indigo-500">✓</span>}
              </button>
            );
          })}
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <Button onClick={openAll} disabled={targets.length === 0}>
            Launch {targets.length || ""} tab{targets.length === 1 ? "" : "s"} ↗
          </Button>
          <Button variant="outline" onClick={copyAll} disabled={targets.length === 0}>
            Copy result URLs
          </Button>
          <Button variant="ghost" onClick={() => onToggle(engines.map((e) => e.id))}>
            Select all
          </Button>
          <Button variant="ghost" onClick={() => onToggle([])}>
            Clear
          </Button>
        </div>
        <p className="mt-3 text-[11px] text-slate-400">
          Tip: browsers may block bursts of tabs — allow pop-ups for this site if only a few open.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {engines.map((e) => (
          <div
            key={e.id}
            className="group flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/60 p-4 transition hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10 dark:bg-white/[0.04]"
          >
            <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-sm font-bold text-white", e.accent)}>
              {e.icon}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{e.name}</p>
              <p className="truncate text-[11px] text-slate-400">{hostOf(buildUrl(e, q))}</p>
            </div>
            <button
              onClick={() => onRun(q, e)}
              className="shrink-0 rounded-xl bg-slate-900/5 px-3 py-2 text-xs font-semibold text-slate-600 transition group-hover:bg-indigo-500 group-hover:text-white dark:bg-white/10 dark:text-slate-200"
            >
              Search
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
