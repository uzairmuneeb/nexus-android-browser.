import { cn } from "../utils/cn";
import type { Engine } from "../lib/engines";

export type HistoryEntry = { q: string; engine: string; at: number };

function dayLabel(ts: number) {
  const d = new Date(ts);
  const today = new Date();
  const yesterday = new Date(today.getTime() - 86400000);
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  if (same(d, today)) return "Today";
  if (same(d, yesterday)) return "Yesterday";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export default function HistoryPanel({
  history,
  engines,
  onRerun,
  onRemove,
  onClear,
}: {
  history: HistoryEntry[];
  engines: Engine[];
  onRerun: (q: string, engineId: string) => void;
  onRemove: (q: string) => void;
  onClear: () => void;
}) {
  if (history.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-slate-300 p-12 text-center dark:border-white/15">
        <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-slate-900/5 text-xl dark:bg-white/10">
          🕘
        </div>
        <p className="font-medium text-slate-700 dark:text-slate-200">No searches yet</p>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Everything you search shows up here — stored only in your browser.
        </p>
      </div>
    );
  }

  const groups = history.reduce<Record<string, HistoryEntry[]>>((acc, entry) => {
    const key = dayLabel(entry.at);
    (acc[key] ||= []).push(entry);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500 dark:text-slate-400">
          {history.length} search{history.length === 1 ? "" : "es"} · stored locally
        </p>
        <button
          onClick={onClear}
          className="rounded-xl bg-rose-500/10 px-3.5 py-2 text-sm font-medium text-rose-600 transition hover:bg-rose-500/20 dark:text-rose-300"
        >
          Clear history
        </button>
      </div>

      {Object.entries(groups).map(([day, entries]) => (
        <section key={day}>
          <h3 className="mb-3 text-xs font-semibold tracking-wider text-slate-400 uppercase">{day}</h3>
          <ul className="space-y-1.5">
            {entries.map((e, i) => {
              const engine = engines.find((x) => x.id === e.engine);
              return (
                <li key={e.q + e.at + i} className="group flex items-center gap-3 rounded-xl px-2 py-2 transition hover:bg-slate-900/[0.04] dark:hover:bg-white/[0.06]">
                  <span
                    className={cn(
                      "grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-gradient-to-br text-[12px] font-bold text-white",
                      engine?.accent ?? "from-slate-500 to-slate-700",
                    )}
                  >
                    {engine?.icon ?? "?"}
                  </span>
                  <button
                    onClick={() => onRerun(e.q, e.engine)}
                    className="min-w-0 flex-1 truncate text-left text-[15px] text-slate-700 dark:text-slate-200"
                  >
                    {e.q}
                  </button>
                  <span className="hidden shrink-0 text-[11px] text-slate-400 sm:block">
                    {new Date(e.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                  <button
                    onClick={() => onRemove(e.q)}
                    aria-label="Remove entry"
                    className="shrink-0 rounded-lg p-1.5 text-slate-300 opacity-0 transition group-hover:opacity-100 hover:text-rose-500"
                  >
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}>
                      <path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14" strokeLinecap="round" />
                    </svg>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
    </div>
  );
}
