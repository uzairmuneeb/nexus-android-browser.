import { useState } from "react";
import { cn } from "../utils/cn";
import { hostOf } from "../lib/engines";
import { Button, Input } from "./ui";

export type QuickLink = { id: string; name: string; url: string };

export const DEFAULT_LINKS: QuickLink[] = [
  { id: "l1", name: "Gmail", url: "https://mail.google.com" },
  { id: "l2", name: "YouTube", url: "https://youtube.com" },
  { id: "l3", name: "GitHub", url: "https://github.com" },
  { id: "l4", name: "Drive", url: "https://drive.google.com" },
  { id: "l5", name: "Maps", url: "https://maps.google.com" },
  { id: "l6", name: "ChatGPT", url: "https://chat.openai.com" },
  { id: "l7", name: "Wikipedia", url: "https://wikipedia.org" },
  { id: "l8", name: "Reddit", url: "https://reddit.com" },
  { id: "l9", name: "Notion", url: "https://notion.so" },
  { id: "l10", name: "LinkedIn", url: "https://linkedin.com/feed" },
  { id: "l11", name: "Spotify", url: "https://open.spotify.com" },
  { id: "l12", name: "Amazon", url: "https://amazon.com" },
];

export default function QuickLinks({
  links,
  onChange,
  onNotify,
}: {
  links: QuickLink[];
  onChange: (l: QuickLink[]) => void;
  onNotify: (msg: string, tone?: "info" | "error" | "success") => void;
}) {
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ name: "", url: "" });

  const add = () => {
    let url = draft.url.trim();
    if (!url) return;
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    const name = draft.name.trim() || hostOf(url);
    onChange([...links, { id: `q${Date.now()}`, name, url }]);
    setDraft({ name: "", url: "" });
    setAdding(false);
    onNotify(`Pinned ${name}`, "success");
  };

  return (
    <div>
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
        {links.map((l) => (
          <div key={l.id} className="group relative">
            <a
              href={l.url}
              target="_blank"
              rel="noreferrer"
              className="flex flex-col items-center gap-2.5 rounded-2xl border border-slate-200/70 bg-white/60 px-3 py-4 text-center backdrop-blur transition-all duration-200 hover:-translate-y-1 hover:border-indigo-300 hover:shadow-xl hover:shadow-indigo-500/10 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-indigo-400/40"
            >
              <img
                src={`https://www.google.com/s2/favicons?sz=64&domain=${hostOf(l.url)}`}
                alt=""
                width={26}
                height={26}
                className="h-[26px] w-[26px] rounded-md"
                onError={(e) => {
                  const el = e.currentTarget as HTMLImageElement;
                  el.style.visibility = "hidden";
                  el.parentElement?.classList.add("bg-slate-200", "dark:bg-white/10");
                }}
              />
              <span className="w-full truncate text-[11px] font-medium text-slate-600 dark:text-slate-300">
                {l.name}
              </span>
            </a>
            <button
              onClick={() => onChange(links.filter((x) => x.id !== l.id))}
              aria-label={`Remove ${l.name}`}
              className="absolute -top-1.5 -right-1.5 grid h-6 w-6 place-items-center rounded-full bg-slate-900 text-white opacity-0 shadow-lg transition group-hover:opacity-100 dark:bg-white dark:text-slate-900"
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3}>
                <path d="M18 6 6 18M6 6l12 12" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        ))}

        <button
          onClick={() => setAdding((v) => !v)}
          className={cn(
            "flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed px-3 py-4 text-[11px] font-medium transition",
            adding
              ? "border-indigo-400 text-indigo-500"
              : "border-slate-300 text-slate-400 hover:border-indigo-400 hover:text-indigo-500 dark:border-white/15 dark:text-slate-500",
          )}
        >
          <span className="grid h-[26px] w-[26px] place-items-center rounded-md bg-slate-900/5 text-lg leading-none dark:bg-white/10">
            +
          </span>
          Pin site
        </button>
      </div>

      {adding && (
        <div className="animate-pop mt-4 rounded-2xl border border-slate-200/80 bg-white/70 p-4 backdrop-blur dark:border-white/10 dark:bg-white/[0.04]">
          <div className="grid gap-3 sm:grid-cols-2">
            <Input
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              placeholder="Name (optional)"
            />
            <Input
              value={draft.url}
              onChange={(e) => setDraft({ ...draft, url: e.target.value })}
              onKeyDown={(e) => e.key === "Enter" && add()}
              placeholder="example.com"
            />
          </div>
          <div className="mt-3 flex gap-2">
            <Button size="sm" onClick={add}>
              Save shortcut
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setAdding(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
