import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { CATEGORIES, hostOf, type Engine, type EngineCategory } from "../lib/engines";
import { googleSearch, type CseConfig } from "../lib/google";
import { Button, Field, Input, Modal, Spinner, Switch } from "./ui";

export type Prefs = {
  openInNewTab: boolean;
  safe: boolean;
  dateRestrict: "" | "d1" | "d7" | "m1" | "y1";
  keepHistory: boolean;
};

type Props = {
  open: boolean;
  onClose: () => void;
  config: CseConfig;
  onConfigChange: (c: CseConfig) => void;
  customEngines: Engine[];
  onCustomEnginesChange: (e: Engine[]) => void;
  prefs: Prefs;
  onPrefsChange: (p: Prefs) => void;
  onNotify: (msg: string, tone?: "info" | "error" | "success") => void;
};

type Tab = "google" | "engines" | "prefs";

const DATE_OPTIONS: { value: Prefs["dateRestrict"]; label: string }[] = [
  { value: "", label: "Any time" },
  { value: "d1", label: "24 hours" },
  { value: "d7", label: "Week" },
  { value: "m1", label: "Month" },
  { value: "y1", label: "Year" },
];

export default function SettingsModal({
  open,
  onClose,
  config,
  onConfigChange,
  customEngines,
  onCustomEnginesChange,
  prefs,
  onPrefsChange,
  onNotify,
}: Props) {
  const [tab, setTab] = useState<Tab>("google");
  const [draft, setDraft] = useState<CseConfig>(config);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [newEngine, setNewEngine] = useState({ name: "", url: "", icon: "★", category: "web" as EngineCategory });

  useEffect(() => {
    if (open) {
      setDraft(config);
      setTestResult(null);
    }
  }, [open, config]);

  const testConnection = async () => {
    if (!draft.apiKey.trim() || !draft.engineId.trim()) {
      setTestResult({ ok: false, msg: "Both an API key and a Search engine ID are required." });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const res = await googleSearch({ config: draft, query: "google", num: 3 });
      setTestResult({ ok: true, msg: `Connected — Google returned ${res.items.length} sample results.` });
      onConfigChange(draft);
      onNotify("Google Custom Search connected 🎉", "success");
    } catch (err) {
      setTestResult({ ok: false, msg: (err as Error).message });
    } finally {
      setTesting(false);
    }
  };

  const addEngine = () => {
    if (!newEngine.name.trim() || !newEngine.url.includes("%s")) {
      onNotify("Add a name and a URL containing %s.", "error");
      return;
    }
    const engine: Engine = {
      id: `custom-${Date.now()}`,
      name: newEngine.name.trim(),
      url: newEngine.url.trim(),
      home: newEngine.url.split("%s")[0],
      category: newEngine.category,
      accent: "from-slate-600 to-indigo-600",
      ring: "text-indigo-500",
      icon: newEngine.icon.trim().slice(0, 2) || "★",
      hint: hostOf(newEngine.url),
    };
    onCustomEnginesChange([...customEngines, engine]);
    setNewEngine({ name: "", url: "", icon: "★", category: "web" });
    onNotify(`Added ${engine.name}`, "success");
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title="Settings"
      subtitle="Connect the Google Custom Search API, add your own engines and tune behaviour."
    >
      <div className="mb-6 flex gap-1 rounded-xl bg-slate-900/5 p-1 dark:bg-white/5">
        {(
          [
            ["google", "Google API"],
            ["engines", "Search engines"],
            ["prefs", "Preferences"],
          ] as [Tab, string][]
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cn(
              "flex-1 rounded-lg px-3 py-2 text-sm font-medium transition",
              tab === id
                ? "bg-white text-slate-900 shadow-sm dark:bg-white/12 dark:text-white"
                : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "google" && (
        <div className="space-y-5">
          <div className="rounded-2xl border border-blue-200/60 bg-blue-500/5 p-4 text-sm leading-relaxed text-slate-600 dark:border-blue-400/20 dark:text-slate-300">
            Keys are stored <strong>only</strong> in this browser’s localStorage and are sent directly to
            <span className="font-mono text-xs"> googleapis.com</span>. Nothing passes through our servers. The free
            tier allows 100 queries per day.
          </div>

          <Field
            label="Google API key"
            hint={
              <>
                Create one in Google Cloud Console with the <em>Custom Search API</em> enabled.{" "}
                <a
                  className="text-indigo-500 hover:underline"
                  href="https://console.cloud.google.com/apis/credentials"
                  target="_blank"
                  rel="noreferrer"
                >
                  Open credentials ↗
                </a>
              </>
            }
          >
            <Input
              value={draft.apiKey}
              onChange={(e) => setDraft({ ...draft, apiKey: e.target.value })}
              placeholder="AIzaSy…"
              type="password"
              autoComplete="off"
            />
          </Field>

          <Field
            label="Search engine ID (cx)"
            hint={
              <>
                From your Programmable Search Engine overview — remember to enable <em>“Search the entire web”</em>.{" "}
                <a
                  className="text-indigo-500 hover:underline"
                  href="https://programmablesearchengine.google.com/controlpanel/overview"
                  target="_blank"
                  rel="noreferrer"
                >
                  Open control panel ↗
                </a>
              </>
            }
          >
            <Input
              value={draft.engineId}
              onChange={(e) => setDraft({ ...draft, engineId: e.target.value })}
              placeholder="e.g. 017576662512468239146:omuauf_lfve"
              autoComplete="off"
            />
          </Field>

          {testResult && (
            <div
              className={cn(
                "rounded-xl px-4 py-3 text-sm",
                testResult.ok
                  ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
                  : "bg-rose-500/10 text-rose-700 dark:text-rose-300",
              )}
            >
              {testResult.msg}
            </div>
          )}

          <div className="flex flex-wrap gap-3">
            <Button onClick={testConnection} disabled={testing}>
              {testing ? <Spinner /> : null}
              {testing ? "Testing…" : "Test & save connection"}
            </Button>
            <Button variant="outline" onClick={() => onConfigChange(draft)}>
              Save only
            </Button>
            {config.apiKey && (
              <Button
                variant="danger"
                onClick={() => {
                  onConfigChange({ apiKey: "", engineId: "" });
                  setDraft({ apiKey: "", engineId: "" });
                  setTestResult(null);
                  onNotify("Google API disconnected.");
                }}
              >
                Disconnect
              </Button>
            )}
          </div>
        </div>
      )}

      {tab === "engines" && (
        <div className="space-y-6">
          <div>
            <p className="mb-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
              Your engines ({customEngines.length})
            </p>
            {customEngines.length === 0 ? (
              <p className="rounded-xl border border-dashed border-slate-300 p-5 text-center text-sm text-slate-400 dark:border-white/15">
                No custom engines yet — add one below with any URL template containing <code>%s</code>.
              </p>
            ) : (
              <ul className="space-y-2">
                {customEngines.map((e) => (
                  <li
                    key={e.id}
                    className="flex items-center gap-3 rounded-xl border border-slate-200/80 bg-white/60 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.03]"
                  >
                    <span className={cn("grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br text-xs font-bold text-white", e.accent)}>
                      {e.icon}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium text-slate-800 dark:text-slate-100">{e.name}</span>
                      <span className="block truncate font-mono text-[11px] text-slate-400">{e.url}</span>
                    </span>
                    <Button
                      size="sm"
                      variant="danger"
                      onClick={() => onCustomEnginesChange(customEngines.filter((x) => x.id !== e.id))}
                    >
                      Remove
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200/80 p-4 dark:border-white/10">
            <p className="mb-3 text-sm font-semibold text-slate-700 dark:text-slate-200">Add an engine</p>
            <div className="grid gap-3 sm:grid-cols-[80px_1fr]">
              <Field label="Icon">
                <Input
                  value={newEngine.icon}
                  onChange={(e) => setNewEngine({ ...newEngine, icon: e.target.value })}
                  className="text-center"
                  maxLength={2}
                />
              </Field>
              <Field label="Name">
                <Input
                  value={newEngine.name}
                  onChange={(e) => setNewEngine({ ...newEngine, name: e.target.value })}
                  placeholder="npm"
                />
              </Field>
            </div>
            <div className="mt-3 space-y-3">
              <Field label="Search URL" hint="Use %s where the query goes — e.g. https://www.npmjs.com/search?q=%s">
                <Input
                  value={newEngine.url}
                  onChange={(e) => setNewEngine({ ...newEngine, url: e.target.value })}
                  placeholder="https://www.npmjs.com/search?q=%s"
                />
              </Field>
              <Field label="Category">
                <select
                  value={newEngine.category}
                  onChange={(e) => setNewEngine({ ...newEngine, category: e.target.value as EngineCategory })}
                  className="w-full rounded-xl border border-slate-300/80 bg-white/70 px-3.5 py-2.5 text-sm focus:border-indigo-400 focus:outline-none dark:border-white/12 dark:bg-white/5 dark:text-white"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Button onClick={addEngine}>Add engine</Button>
            </div>
          </div>
        </div>
      )}

      {tab === "prefs" && (
        <div className="space-y-4">
          <Switch
            checked={prefs.openInNewTab}
            onChange={(v) => onPrefsChange({ ...prefs, openInNewTab: v })}
            label="Open search results in a new tab"
          />
          <Switch
            checked={prefs.keepHistory}
            onChange={(v) => onPrefsChange({ ...prefs, keepHistory: v })}
            label="Remember search history on this device"
          />
          <Switch
            checked={prefs.safe}
            onChange={(v) => onPrefsChange({ ...prefs, safe: v })}
            label="SafeSearch (filters explicit results)"
          />

          <div className="pt-2">
            <p className="mb-2 text-xs font-semibold tracking-wide text-slate-500 uppercase dark:text-slate-400">
              Result freshness
            </p>
            <div className="flex flex-wrap gap-2">
              {DATE_OPTIONS.map((d) => (
                <button
                  key={d.value}
                  onClick={() => onPrefsChange({ ...prefs, dateRestrict: d.value })}
                  className={cn(
                    "rounded-xl px-3.5 py-2 text-sm font-medium transition",
                    prefs.dateRestrict === d.value
                      ? "bg-indigo-500 text-white shadow-md shadow-indigo-500/25"
                      : "bg-slate-900/5 text-slate-600 hover:bg-slate-900/10 dark:bg-white/8 dark:text-slate-300 dark:hover:bg-white/15",
                  )}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
}
