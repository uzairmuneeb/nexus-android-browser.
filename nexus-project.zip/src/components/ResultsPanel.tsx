import { useCallback, useEffect, useMemo, useState } from "react";
import { cn } from "../utils/cn";
import { faviconFor, googleSearch, type CseConfig, type SearchResult } from "../lib/google";
import { Button } from "./ui";

export type ResultFilters = {
  safe: boolean;
  dateRestrict: "" | "d1" | "d7" | "m1" | "y1";
  mode: "web" | "image";
};

type Props = {
  query: string;
  config: CseConfig;
  filters: ResultFilters;
  onOpenSettings: () => void;
  onNotify: (msg: string, tone?: "info" | "error" | "success") => void;
  onWebSearch: (q: string) => void;
};

const STEPS = [
  {
    n: 1,
    title: "Create a Programmable Search Engine",
    body: "Head to programmablesearchengine.google.com, add a new engine and turn on “Search the entire web”.",
    link: "https://programmablesearchengine.google.com/controlpanel/all",
    cta: "Open control panel",
  },
  {
    n: 2,
    title: "Copy the Search engine ID (cx)",
    body: "It’s on the Overview page — a 40+ character string. Paste it in Settings.",
    link: "https://programmablesearchengine.google.com/controlpanel/overview",
    cta: "Get engine ID",
  },
  {
    n: 3,
    title: "Get a free API key",
    body: "Enable the “Custom Search API” in Google Cloud, then create an API key. Free tier = 100 queries/day.",
    link: "https://developers.google.com/custom-search/v1/introduction#identify_your_application_to_google_with_api_key",
    cta: "Get API key",
  },
];

export default function ResultsPanel({ query, config, filters, onOpenSettings, onNotify, onWebSearch }: Props) {
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<SearchResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState<number | null>(null);
  const [secs, setSecs] = useState<number | null>(null);
  const ready = Boolean(config.apiKey.trim() && config.engineId.trim());
  const start = (page - 1) * 10 + 1;

  useEffect(() => setPage(1), [query, filters.mode, filters.dateRestrict]);

  const run = useCallback(
    async (signal?: AbortSignal) => {
      if (!ready || !query.trim()) return;
      setLoading(true);
      setError(null);
      try {
        const res = await googleSearch({
          config,
          query,
          start,
          num: 10,
          safe: filters.safe,
          dateRestrict: filters.dateRestrict,
          searchType: filters.mode === "image" ? "image" : undefined,
          signal,
        });
        setItems(res.items);
        setTotal(res.total);
        setSecs(res.time);
      } catch (err) {
        if ((err as Error)?.name === "AbortError") return;
        setError((err as Error).message || "Search failed.");
        setItems([]);
        onNotify((err as Error).message || "Google search failed.", "error");
      } finally {
        setLoading(false);
      }
    },
    [ready, query, start, config, filters, onNotify],
  );

  useEffect(() => {
    if (!ready || !query.trim()) return;
    const ctrl = new AbortController();
    run(ctrl.signal);
    return () => ctrl.abort();
  }, [run, query]);

  const skeletons = useMemo(() => Array.from({ length: 6 }), []);

  /* ------------------------------------------------ empty / unconnected -- */
  if (!ready) {
    return (
      <div className="mx-auto max-w-3xl">
        <div className="relative overflow-hidden rounded-3xl border border-slate-200/80 bg-white/70 p-7 shadow-xl shadow-slate-900/5 backdrop-blur-xl dark:border-white/10 dark:bg-white/[0.04]">
          <div className="pointer-events-none absolute -top-24 -right-16 h-56 w-56 rounded-full bg-gradient-to-br from-blue-500/25 to-violet-500/10 blur-3xl" />
          <div className="relative">
            <span className="inline-flex items-center gap-2 rounded-full bg-amber-500/10 px-3 py-1 text-[11px] font-semibold tracking-wide text-amber-600 uppercase dark:text-amber-400">
              Google API not connected
            </span>
            <h3 className="font-display mt-3 text-2xl font-bold text-slate-900 dark:text-white">
              Render live <span className="text-gradient">Google</span> results inside Nexus
            </h3>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              Without a key, Nexus launches your query straight into Google in a new tab. Connect the free
              Custom&nbsp;Search&nbsp;JSON&nbsp;API and results, thumbnails and pagination appear right here.
            </p>

            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              {STEPS.map((s) => (
                <a
                  key={s.n}
                  href={s.link}
                  target="_blank"
                  rel="noreferrer"
                  className="group rounded-2xl border border-slate-200/80 bg-white/60 p-4 transition hover:-translate-y-0.5 hover:border-indigo-300 hover:shadow-lg dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-indigo-400/40"
                >
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 text-xs font-bold text-white">
                    {s.n}
                  </span>
                  <p className="mt-3 text-sm font-semibold text-slate-800 dark:text-slate-100">{s.title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">{s.body}</p>
                  <span className="mt-2 inline-block text-[11px] font-semibold text-indigo-500 group-hover:underline">
                    {s.cta} ↗
                  </span>
                </a>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Button onClick={onOpenSettings}>Connect Google API</Button>
              <Button variant="outline" onClick={() => onWebSearch(query || "google")}>
                Search on google.com instead ↗
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!query.trim()) {
    return (
      <div className="mx-auto max-w-md rounded-3xl border border-dashed border-slate-300 p-10 text-center dark:border-white/15">
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Type a query above to pull results from Google.
        </p>
      </div>
    );
  }

  /* ------------------------------------------------------------ results -- */
  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
        <p>
          {loading ? (
            "Searching Google…"
          ) : (
            <>
              About <span className="font-semibold text-slate-700 dark:text-slate-200">{total?.toLocaleString() ?? items.length}</span>
              {total ? " results" : ""} {secs !== null && <>· {secs.toFixed(2)}s</>} · page {page}
            </>
          )}
        </p>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 font-medium text-emerald-600 dark:text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Google API connected
          </span>
          <button
            onClick={() => run()}
            className="rounded-full px-2.5 py-1 font-medium text-slate-500 transition hover:bg-slate-900/5 hover:text-slate-800 dark:hover:bg-white/10 dark:hover:text-white"
          >
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-5 rounded-2xl border border-rose-300/60 bg-rose-500/5 p-5 dark:border-rose-400/25">
          <p className="text-sm font-semibold text-rose-600 dark:text-rose-300">Couldn’t complete the search</p>
          <p className="mt-1 text-sm leading-relaxed text-rose-700/80 dark:text-rose-200/70">{error}</p>
          <div className="mt-3 flex gap-2">
            <Button size="sm" variant="soft" onClick={() => run()}>
              Try again
            </Button>
            <Button size="sm" variant="ghost" onClick={onOpenSettings}>
              Check credentials
            </Button>
          </div>
        </div>
      )}

      {loading && filters.mode === "image" && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {skeletons.slice(0, 8).map((_, i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-slate-200/70 dark:border-white/10">
              <div className="skeleton aspect-square w-full" />
              <div className="space-y-2 p-3">
                <div className="skeleton h-2.5 w-20 rounded" />
                <div className="skeleton h-3 w-full rounded" />
              </div>
            </div>
          ))}
        </div>
      )}

      {loading &&
        filters.mode === "web" &&
        skeletons.map((_, i) => (
          <div key={i} className="mb-7 flex gap-4">
            <div className="flex-1 space-y-2.5">
              <div className="skeleton h-3 w-44 rounded" />
              <div className="skeleton h-5 w-3/4 rounded" />
              <div className="skeleton h-3 w-full rounded" />
              <div className="skeleton h-3 w-5/6 rounded" />
            </div>
            <div className="skeleton h-16 w-24 rounded-xl" />
          </div>
        ))}

      {!loading && filters.mode === "image" && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((r) => (
            <a
              key={r.link}
              href={r.link}
              target="_blank"
              rel="noreferrer"
              className="group overflow-hidden rounded-2xl border border-slate-200/80 bg-white/60 transition hover:-translate-y-1 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04]"
            >
              <div className="aspect-square overflow-hidden bg-slate-100 dark:bg-white/5">
                {r.thumbnail && (
                  <img
                    src={r.thumbnail}
                    alt={r.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                )}
              </div>
              <div className="p-2.5">
                <p className="truncate text-[11px] text-slate-400">{r.displayLink}</p>
                <p className="line-clamp-2 text-xs leading-snug font-medium text-slate-800 dark:text-slate-100">
                  {r.title}
                </p>
              </div>
            </a>
          ))}
        </div>
      )}

      {!loading && filters.mode === "web" && (
        <ol className="space-y-7">
          {items.map((r, i) => (
            <li key={r.link + i} className="animate-rise flex gap-4">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2.5">
                  <img
                    src={faviconFor(r.link, 32)}
                    alt=""
                    width={18}
                    height={18}
                    className="h-[18px] w-[18px] rounded-sm"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).style.visibility = "hidden";
                    }}
                  />
                  <div className="min-w-0">
                    <p className="truncate text-[13px] leading-tight text-slate-700 dark:text-slate-300">
                      {r.displayLink}
                    </p>
                    <p className="truncate text-[11px] text-slate-400">
                      {r.link.replace(/^https?:\/\//, "").slice(0, 90)}
                    </p>
                  </div>
                </div>
                <a
                  href={r.link}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-1.5 block text-[19px] leading-snug font-medium text-[#1a0dab] visited:text-[#609] hover:underline dark:text-[#8ab4f8] dark:visited:text-[#c58af9]"
                >
                  {r.title}
                </a>
                <p className="mt-1 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-300/90">
                  {r.snippet}
                </p>
              </div>
              {r.thumbnail && (
                <a
                  href={r.link}
                  target="_blank"
                  rel="noreferrer"
                  className="hidden h-[86px] w-[128px] shrink-0 overflow-hidden rounded-xl border border-slate-200/70 bg-slate-100 sm:block dark:border-white/10 dark:bg-white/5"
                >
                  <img src={r.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" />
                </a>
              )}
            </li>
          ))}
        </ol>
      )}

      {!loading && items.length === 0 && !error && (
        <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-white/15">
          <p className="text-sm text-slate-500 dark:text-slate-400">
            No {filters.mode} results for “{query}”. Try fewer words or check the engine’s scope.
          </p>
        </div>
      )}

      {!loading && items.length > 0 && (
        <div className="mt-10 flex items-center justify-center gap-3 border-t border-slate-200/70 pt-6 dark:border-white/10">
          <Button
            variant="outline"
            size="sm"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            ← Previous
          </Button>
          <span className={cn("text-xs text-slate-400")}>
            results {start}–{start + items.length - 1} of {total ? total.toLocaleString() : "?"}
          </span>
          <Button variant="outline" size="sm" disabled={start + items.length > 90} onClick={() => setPage((p) => p + 1)}>
            Next →
          </Button>
        </div>
      )}
    </div>
  );
}
