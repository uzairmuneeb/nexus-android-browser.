/**
 * Google Programmable Search (Custom Search JSON API) client.
 * https://developers.google.com/custom-search/v1/overview
 *
 * The app works without credentials (it deep-links to google.com), but when the
 * visitor supplies a free API key + Search engine ID the results render inline.
 */

export type SearchResult = {
  title: string;
  link: string;
  displayLink: string;
  snippet: string;
  formattedUrl?: string;
  thumbnail?: string;
  thumbWidth?: number;
  thumbHeight?: number;
};

export type SearchResponse = {
  items: SearchResult[];
  total: number | null;
  time: number | null;
  start: number;
};

export type CseConfig = {
  apiKey: string;
  engineId: string;
};

export type CseOptions = {
  query: string;
  start?: number;
  num?: number;
  safe?: boolean;
  dateRestrict?: "" | "d1" | "d7" | "m1" | "y1";
  country?: string;
  language?: string;
  searchType?: "image";
  signal?: AbortSignal;
};

const ENDPOINT = "https://www.googleapis.com/customsearch/v1";

export function describeCseError(status: number, body: unknown): string {
  const reason =
    body && typeof body === "object" && "error" in body
      ? ((body as { error?: { message?: string } }).error?.message ?? "")
      : "";
  switch (status) {
    case 400:
      return reason || "Bad request — check the Search engine ID (cx).";
    case 403:
      return "Access denied. The API key needs “Custom Search API” enabled and HTTP referrer restrictions removed.";
    case 429:
      return "Daily quota reached (100 free queries/day). Try again tomorrow.";
    default:
      return reason || `Request failed with status ${status}.`;
  }
}

export async function googleSearch(opts: CseOptions & { config: CseConfig }): Promise<SearchResponse> {
  const {
    config,
    query,
    start = 1,
    num = 10,
    safe = false,
    dateRestrict = "",
    country = "",
    language = "",
    searchType,
    signal,
  } = opts;

  if (!config.apiKey || !config.engineId) throw new Error("Missing Google API key or Search engine ID.");
  if (!query.trim()) return { items: [], total: null, time: null, start };

  const params = new URLSearchParams({
    key: config.apiKey.trim(),
    cx: config.engineId.trim(),
    q: query.trim(),
    num: String(Math.min(Math.max(num, 1), 10)),
    start: String(Math.min(Math.max(start, 1), 91)),
    safe: safe ? "active" : "off",
  });
  if (dateRestrict) params.set("dateRestrict", dateRestrict);
  if (country) params.set("gl", country);
  if (language) params.set("hl", language);
  if (searchType === "image") {
    params.set("searchType", "image");
    params.set("imgSize", "large");
  }

  const res = await fetch(`${ENDPOINT}?${params.toString()}`, { signal });
  const body = await res.json().catch(() => null);
  if (!res.ok) throw new Error(describeCseError(res.status, body));

  const data = body as {
    items?: Array<{
      title: string;
      link: string;
      displayLink?: string;
      snippet?: string;
      formattedUrl?: string;
      pagemap?: {
        cse_thumbnail?: { src?: string; width?: string; height?: string }[];
        cse_image?: { src?: string }[];
      };
    }>;
    searchInformation?: { totalResults?: string; searchTime?: number };
  };

  const items: SearchResult[] = (data.items ?? []).map((item) => {
    const thumb =
      item.pagemap?.cse_thumbnail?.[0]?.src ?? item.pagemap?.cse_image?.[0]?.src ?? undefined;
    return {
      title: item.title,
      link: item.link,
      displayLink: item.displayLink ?? new URL(item.link).hostname.replace(/^www\./, ""),
      snippet: item.snippet ?? "",
      formattedUrl: item.formattedUrl,
      thumbnail: thumb,
      thumbWidth: item.pagemap?.cse_thumbnail?.[0]?.width
        ? Number(item.pagemap.cse_thumbnail[0].width)
        : undefined,
      thumbHeight: item.pagemap?.cse_thumbnail?.[0]?.height
        ? Number(item.pagemap.cse_thumbnail[0].height)
        : undefined,
    };
  });

  const totalRaw = data.searchInformation?.totalResults;
  return {
    items,
    total: totalRaw && Number(totalRaw) > 0 ? Number(totalRaw) : null,
    time: data.searchInformation?.searchTime ?? null,
    start,
  };
}

export function faviconFor(link: string, size = 64) {
  let host = "";
  try {
    host = new URL(link).hostname;
  } catch {
    return "";
  }
  return `https://www.google.com/s2/favicons?sz=${size}&domain=${host}`;
}
