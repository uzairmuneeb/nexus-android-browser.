export type EngineCategory = "web" | "media" | "code" | "reference" | "shopping" | "social";

export type Engine = {
  id: string;
  name: string;
  /** URL template containing %s for the encoded query */
  url: string;
  home: string;
  category: EngineCategory;
  accent: string; // tailwind gradient classes
  ring: string; // text color
  icon: string; // emoji or short glyph
  lucky?: boolean; // supports "I'm feeling lucky"
  builtin?: boolean;
  hint?: string;
};

export const ENGINES: Engine[] = [
  {
    id: "google",
    name: "Google",
    url: "https://www.google.com/search?q=%s",
    home: "https://www.google.com",
    category: "web",
    accent: "from-blue-500 via-sky-500 to-cyan-400",
    ring: "text-blue-500",
    icon: "G",
    lucky: true,
    builtin: true,
    hint: "Full web index · instant answers · AI overviews",
  },
  {
    id: "bing",
    name: "Bing",
    url: "https://www.bing.com/search?q=%s",
    home: "https://www.bing.com",
    category: "web",
    accent: "from-teal-500 to-emerald-500",
    ring: "text-teal-600 dark:text-teal-400",
    icon: "b",
    builtin: true,
    hint: "Copilot answers baked in",
  },
  {
    id: "ddg",
    name: "DuckDuckGo",
    url: "https://duckduckgo.com/?q=%s",
    home: "https://duckduckgo.com",
    category: "web",
    accent: "from-orange-500 to-red-500",
    ring: "text-orange-500",
    icon: "D",
    builtin: true,
    hint: "Private, untracked searching",
  },
  {
    id: "perplexity",
    name: "Perplexity",
    url: "https://www.perplexity.ai/search?q=%s",
    home: "https://www.perplexity.ai",
    category: "web",
    accent: "from-indigo-500 to-violet-500",
    ring: "text-indigo-500",
    icon: "P",
    builtin: true,
    hint: "AI answers with citations",
  },
  {
    id: "youtube",
    name: "YouTube",
    url: "https://www.youtube.com/results?search_query=%s",
    home: "https://www.youtube.com",
    category: "media",
    accent: "from-red-600 to-rose-500",
    ring: "text-red-600 dark:text-red-400",
    icon: "▶",
    builtin: true,
    hint: "Video results & channels",
  },
  {
    id: "images",
    name: "Images",
    url: "https://www.google.com/search?q=%s&udm=2",
    home: "https://images.google.com",
    category: "media",
    accent: "from-fuchsia-500 to-purple-500",
    ring: "text-fuchsia-500",
    icon: "◧",
    builtin: true,
    hint: "Google Images grid",
  },
  {
    id: "maps",
    name: "Maps",
    url: "https://www.google.com/maps/search/%s",
    home: "https://maps.google.com",
    category: "media",
    accent: "from-green-500 to-emerald-600",
    ring: "text-emerald-600 dark:text-emerald-400",
    icon: "◈",
    builtin: true,
    hint: "Places, directions, reviews",
  },
  {
    id: "news",
    name: "News",
    url: "https://news.google.com/search?q=%s",
    home: "https://news.google.com",
    category: "web",
    accent: "from-slate-600 to-slate-800",
    ring: "text-slate-700 dark:text-slate-300",
    icon: "📰",
    builtin: true,
    hint: "Fresh headlines worldwide",
  },
  {
    id: "scholar",
    name: "Scholar",
    url: "https://scholar.google.com/scholar?q=%s",
    home: "https://scholar.google.com",
    category: "reference",
    accent: "from-blue-600 to-indigo-600",
    ring: "text-indigo-600 dark:text-indigo-400",
    icon: "🎓",
    builtin: true,
    hint: "Papers, citations, theses",
  },
  {
    id: "wikipedia",
    name: "Wikipedia",
    url: "https://en.wikipedia.org/w/index.php?search=%s",
    home: "https://wikipedia.org",
    category: "reference",
    accent: "from-zinc-500 to-zinc-700",
    ring: "text-zinc-600 dark:text-zinc-300",
    icon: "W",
    builtin: true,
    hint: "The free encyclopedia",
  },
  {
    id: "github",
    name: "GitHub",
    url: "https://github.com/search?q=%s&type=repositories",
    home: "https://github.com",
    category: "code",
    accent: "from-gray-700 to-black",
    ring: "text-gray-800 dark:text-gray-200",
    icon: "⌥",
    builtin: true,
    hint: "Repos, code and issues",
  },
  {
    id: "stackoverflow",
    name: "Stack Overflow",
    url: "https://stackoverflow.com/search?q=%s",
    home: "https://stackoverflow.com",
    category: "code",
    accent: "from-orange-500 to-amber-500",
    ring: "text-amber-600 dark:text-amber-400",
    icon: "{}",
    builtin: true,
    hint: "Answers for developers",
  },
  {
    id: "reddit",
    name: "Reddit",
    url: "https://www.reddit.com/search/?q=%s",
    home: "https://reddit.com",
    category: "social",
    accent: "from-orange-600 to-red-500",
    ring: "text-orange-600 dark:text-orange-400",
    icon: "◕",
    builtin: true,
    hint: "Real human opinions",
  },
  {
    id: "amazon",
    name: "Amazon",
    url: "https://www.amazon.com/s?k=%s",
    home: "https://amazon.com",
    category: "shopping",
    accent: "from-amber-500 to-orange-600",
    ring: "text-amber-600 dark:text-amber-400",
    icon: "🛒",
    builtin: true,
    hint: "Products and prices",
  },
  {
    id: "weather",
    name: "Weather",
    url: "https://www.google.com/search?q=weather+%s",
    home: "https://www.google.com/search?q=weather",
    category: "reference",
    accent: "from-sky-400 to-blue-500",
    ring: "text-sky-500",
    icon: "☀",
    builtin: true,
    hint: "Forecast for any city",
  },
];

export const CATEGORIES: { id: EngineCategory; label: string }[] = [
  { id: "web", label: "Web & AI" },
  { id: "media", label: "Media" },
  { id: "code", label: "Developers" },
  { id: "reference", label: "Reference" },
  { id: "social", label: "Social" },
  { id: "shopping", label: "Shopping" },
];

export function buildUrl(engine: Engine, query: string) {
  if (!engine.url.includes("%s")) return engine.url;
  return engine.url.replace("%s", encodeURIComponent(query.trim()));
}

export function luckyUrl(query: string) {
  return `https://www.google.com/search?q=${encodeURIComponent(query.trim())}&btnI=1&nf=1`;
}

export function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

/** Trending / suggested seed queries shown on the empty state. */
export const TRENDING: string[] = [
  "how do jwt refresh tokens work",
  "best mechanical keyboards 2026",
  "james webb telescope latest images",
  "react 19 use() hook explained",
  "focaccia recipe no knead",
  "tokyo 7 day itinerary",
  "who won the last formula 1 race",
  "css container queries examples",
];
