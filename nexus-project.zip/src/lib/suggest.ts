/**
 * Live Google Autocomplete ("search-as-you-type").
 *
 * Google's public suggest endpoint sends no CORS headers, so we hop through a
 * public JSON proxy and fall back to a local, history-aware predictor when the
 * network is unavailable. Everything degrades silently — the UI never blocks.
 */

const CACHE = new Map<string, string[]>();
let controller: AbortController | null = null;

const PROXIES: ((url: string) => string)[] = [
  (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
  (url) => `https://corsproxy.io/?url=${encodeURIComponent(url)}`,
  (url) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`,
];

function parseFirefox(payload: unknown): string[] {
  // client=firefox → ["query", ["a", "b", ...]]
  if (Array.isArray(payload) && Array.isArray(payload[1])) {
    return payload[1].filter((s): s is string => typeof s === "string").slice(0, 8);
  }
  // Some proxies wrap the body in an object
  if (payload && typeof payload === "object") {
    const contents = (payload as { contents?: string }).contents;
    if (typeof contents === "string") {
      try {
        return parseFirefox(JSON.parse(contents));
      } catch {
        return [];
      }
    }
  }
  return [];
}

export function localSuggestions(query: string, history: string[], trending: string[]): string[] {
  const q = query.trim().toLowerCase();
  if (!q) return trending.slice(0, 6);
  const pool = [...history, ...trending, `${q} tutorial`, `${q} vs`, `${q} meaning`, `best ${q}`];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of pool) {
    const key = item.toLowerCase();
    if (key.includes(q) && !seen.has(key)) {
      seen.add(key);
      out.push(item);
    }
    if (out.length >= 8) break;
  }
  return out;
}

export async function fetchSuggestions(
  query: string,
  history: string[],
  trending: string[],
): Promise<{ list: string[]; live: boolean }> {
  const q = query.trim();
  if (!q) return { list: trending.slice(0, 6), live: false };
  if (CACHE.has(q.toLowerCase())) return { list: CACHE.get(q.toLowerCase())!, live: true };

  const target = `https://suggestqueries.google.com/complete/search?client=firefox&hl=en&q=${encodeURIComponent(q)}`;

  if (controller) controller.abort();
  controller = new AbortController();
  const signal = controller.signal;

  for (const wrap of PROXIES) {
    try {
      const res = await fetch(wrap(target), { signal });
      if (!res.ok) continue;
      const text = await res.text();
      const list = parseFirefox(JSON.parse(text));
      if (list.length) {
        CACHE.set(q.toLowerCase(), list);
        if (CACHE.size > 300) CACHE.delete(CACHE.keys().next().value as string);
        return { list, live: true };
      }
    } catch (err) {
      if ((err as Error)?.name === "AbortError") return { list: localSuggestions(q, history, trending), live: false };
    }
  }

  return { list: localSuggestions(q, history, trending), live: false };
}
