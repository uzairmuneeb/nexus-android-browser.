import { useEffect, useMemo, useState } from "react";
import { cn } from "./utils/cn";
import { buildUrl, ENGINES, luckyUrl, TRENDING, type Engine } from "./lib/engines";
import { useClock, useLocalStorage, useTheme, useToasts } from "./lib/hooks";
import type { CseConfig } from "./lib/google";
import SearchBar from "./components/SearchBar";
import ResultsPanel, { type ResultFilters } from "./components/ResultsPanel";
import EverywherePanel from "./components/EverywherePanel";
import HistoryPanel, { type HistoryEntry } from "./components/HistoryPanel";
import QuickLinks, { DEFAULT_LINKS, type QuickLink } from "./components/QuickLinks";
import SettingsModal, { type Prefs } from "./components/SettingsModal";
import { Button, LogoMark, GoogleWordmark } from "./components/ui";

type Tab = "results" | "everywhere" | "links" | "history";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "results", label: "Google results", icon: "🔍" },
  { id: "everywhere", label: "Everywhere", icon: "🌐" },
  { id: "links", label: "Shortcuts", icon: "📌" },
  { id: "history", label: "History", icon: "🕘" },
];

const RAIL = ["google", "images", "maps", "news", "youtube", "wikipedia", "github", "ddg", "perplexity"];

const OPERATORS: { label: string; apply: (q: string) => string; note: string }[] = [
  { label: "“exact phrase”", apply: (q) => `"${q}"`, note: "Match the phrase exactly" },
  { label: "site:", apply: (q) => `${q} site:stackoverflow.com`, note: "Limit to one website" },
  { label: "filetype:pdf", apply: (q) => `${q} filetype:pdf`, note: "Find documents" },
  { label: "-exclude", apply: (q) => `${q} -pinterest`, note: "Remove a term" },
  { label: "OR", apply: (q) => `${q} OR alternative`, note: "Broaden the match" },
  { label: "intitle:", apply: (q) => `${q} intitle:guide`, note: "Word in the title" },
];

export default function App() {
  const { theme, toggle } = useTheme();
  const now = useClock();
  const { toasts, push } = useToasts();

  const [query, setQuery] = useState("");
  const [engineId, setEngineId] = useLocalStorage<string>("engine", "google");
  const [customEngines, setCustomEngines] = useLocalStorage<Engine[]>("customEngines", []);
  const [links, setLinks] = useLocalStorage<QuickLink[]>("links", DEFAULT_LINKS);
  const [history, setHistory] = useLocalStorage<HistoryEntry[]>("history", []);
  const [selected, setSelected] = useLocalStorage<string[]>("everywhereSet", ["google", "bing", "ddg", "youtube"]);
  const [prefs, setPrefs] = useLocalStorage<Prefs>("prefs", {
    openInNewTab: true,
    safe: false,
    dateRestrict: "",
    keepHistory: true,
  });
  const [config, setConfig] = useLocalStorage<CseConfig>("cse", { apiKey: "", engineId: "" });

  const [tab, setTab] = useState<Tab>("results");
  const [mode, setMode] = useState<ResultFilters["mode"]>("web");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [focusKey, setFocusKey] = useState(0);

  const engines = useMemo(() => [...ENGINES, ...customEngines], [customEngines]);
  const engine = useMemo(() => engines.find((e) => e.id === engineId) ?? ENGINES[0], [engines, engineId]);
  const googleConnected = Boolean(config.apiKey.trim() && config.engineId.trim());

  const filters: ResultFilters = useMemo(
    () => ({ safe: prefs.safe, dateRestrict: prefs.dateRestrict, mode }),
    [prefs.safe, prefs.dateRestrict, mode],
  );

  /* ------------------------------------------------------------- actions */

  const remember = (q: string, id: string) => {
    if (!prefs.keepHistory || !q.trim()) return;
    setHistory(
      (prev) => [{ q: q.trim(), engine: id, at: Date.now() }, ...prev.filter((h) => h.q !== q.trim())].slice(0, 120),
    );
  };

  const launch = (target: string, newTab: boolean) => {
    if (newTab) window.open(target, "_blank", "noopener,noreferrer");
    else window.location.href = target;
  };

  const submit = (q: string, e: Engine, opts?: { lucky?: boolean; forceNewTab?: boolean }) => {
    const value = q.trim();
    if (!value) {
      push("Type something to search for.", "error");
      setFocusKey((k) => k + 1);
      return;
    }
    remember(value, e.id);

    if (opts?.lucky) {
      push("Opening the top result with “I’m Feeling Lucky”…");
      launch(luckyUrl(value), true);
      return;
    }

    // Google is special: render results inline when the API is connected,
    // otherwise hand the query straight to google.com.
    if (e.id === "google") {
      setTab("results");
      if (googleConnected && !opts?.forceNewTab) return;
      push(
        googleConnected
          ? "Opening google.com in a new tab…"
          : "Add a Google API key to see results inline — opening google.com for now.",
      );
      launch(buildUrl(e, value), true);
      return;
    }

    launch(buildUrl(e, value), opts?.forceNewTab ?? prefs.openInNewTab);
    push(`Searching ${e.name} for “${value}”`);
  };

  const greeting = useMemo(() => {
    const h = now.getHours();
    if (h < 5) return "Still up?";
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  }, [now]);

  /* --------------------------------------------------------------- chrome */

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "," && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setSettingsOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const historyTerms = useMemo(() => history.map((h) => h.q), [history]);

  /* Allow ?q=deep links (e.g. set Nexus as a browser search engine). */
  useEffect(() => {
    const q = new URLSearchParams(window.location.search).get("q");
    if (!q) return;
    setQuery(q);
    submit(q, ENGINES[0]);
    window.history.replaceState({}, "", window.location.pathname);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    document.title = query.trim() ? `${query.trim()} — Nexus Search` : "Nexus Search — Google-powered search hub";
  }, [query]);

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#f6f7fb] text-slate-900 transition-colors duration-500 dark:bg-ink-950 dark:text-slate-100">
      {/* ---------------------------------------------------- background -- */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="animate-float absolute -top-40 -left-32 h-[34rem] w-[34rem] rounded-full bg-gradient-to-br from-blue-500/25 via-indigo-500/15 to-transparent blur-[110px]" />
        <div
          className="animate-float absolute -right-40 top-20 h-[30rem] w-[30rem] rounded-full bg-gradient-to-br from-fuchsia-500/20 via-violet-500/15 to-transparent blur-[120px]"
          style={{ animationDelay: "-3s" }}
        />
        <div
          className="animate-float absolute bottom-0 left-1/3 h-[26rem] w-[26rem] rounded-full bg-gradient-to-br from-cyan-400/20 to-emerald-400/10 blur-[120px]"
          style={{ animationDelay: "-6s" }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-20%,rgba(99,102,241,0.16),transparent_55%)]" />
        <div className="absolute inset-0 opacity-[0.035] [background-image:linear-gradient(to_right,#64748b_1px,transparent_1px),linear-gradient(to_bottom,#64748b_1px,transparent_1px)] [background-size:64px_64px] dark:opacity-[0.06]" />
      </div>

      {/* --------------------------------------------------------- header -- */}
      <header className="relative z-20 mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-5">
        <div className="flex items-center gap-3">
          <LogoMark />
          <div className="leading-tight">
            <p className="font-display text-[17px] font-bold tracking-tight">Nexus</p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">Google-powered search hub</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setFocusKey((k) => k + 1)}
            className="hidden items-center gap-2 rounded-xl border border-slate-200/80 bg-white/60 px-3 py-2 text-xs text-slate-500 transition hover:border-indigo-300 hover:text-slate-800 sm:flex dark:border-white/10 dark:bg-white/5 dark:text-slate-400 dark:hover:text-white"
          >
            <kbd className="font-sans font-semibold">⌘</kbd>
            <kbd className="font-sans font-semibold">K</kbd>
            <span>to search</span>
          </button>
          {googleConnected && (
            <span className="hidden items-center gap-1.5 rounded-xl bg-emerald-500/10 px-3 py-2 text-xs font-medium text-emerald-600 md:flex dark:text-emerald-400">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" /> Google live
            </span>
          )}
          <button
            onClick={toggle}
            aria-label="Toggle theme"
            className="rounded-xl border border-slate-200/80 bg-white/60 p-2.5 text-slate-500 transition hover:text-indigo-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
          >
            {theme === "dark" ? (
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}>
                <circle cx="12" cy="12" r="4.2" />
                <path
                  d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M18.8 5.2l-1.4 1.4M6.6 17.4l-1.4 1.4"
                  strokeLinecap="round"
                />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z" strokeLinecap="round" />
              </svg>
            )}
          </button>
          <Button variant="soft" size="sm" onClick={() => setSettingsOpen(true)} className="!px-3 !py-2.5">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.9}>
              <circle cx="12" cy="12" r="3.2" />
              <path d="M12 2.8v2.4M12 18.8v2.4M4.6 4.6l1.7 1.7M17.7 17.7l1.7 1.7M19.4 4.6l-1.7 1.7M6.3 17.7l-1.7 1.7M2.8 12h2.4M18.8 12h2.4" strokeLinecap="round" />
            </svg>
            <span className="hidden sm:inline">Settings</span>
          </Button>
        </div>
      </header>

      {/* ----------------------------------------------------------- hero -- */}
      <section className="relative z-10 mx-auto max-w-3xl px-5 pt-8 pb-4 text-center sm:pt-14">
        <p className="animate-rise mb-4 inline-flex items-center gap-2 rounded-full border border-slate-200/80 bg-white/60 px-3.5 py-1.5 text-xs text-slate-600 backdrop-blur dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          {googleConnected ? "Live Google results inline" : "Google, Bing, YouTube, Scholar + 11 more"}
        </p>

        <h1 className="animate-rise font-display text-4xl leading-tight font-bold tracking-tight sm:text-6xl">
          {greeting}. <span className="text-gradient">Search everything.</span>
        </h1>

        <p className="animate-rise mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-slate-600 sm:text-base dark:text-slate-400">
          One box for the whole web. Nexus queries <GoogleWordmark className="text-[1.05em]" /> directly, then hands your
          search to any of {engines.length} engines — results, images, videos, papers and code.
        </p>

        <div className="animate-rise mt-9" style={{ animationDelay: "60ms" }}>
          <SearchBar
            query={query}
            onQueryChange={setQuery}
            engine={engine}
            engines={engines}
            onEngineChange={(e) => setEngineId(e.id)}
            onSubmit={submit}
            history={historyTerms}
            trending={TRENDING}
            onNotify={push}
            autoFocusKey={focusKey}
          />
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          {TRENDING.slice(0, 5).map((t) => (
            <button
              key={t}
              onClick={() => {
                setQuery(t);
                submit(t, engine);
              }}
              className="rounded-full border border-slate-200/80 bg-white/50 px-3.5 py-1.5 text-[12.5px] text-slate-600 transition hover:-translate-y-0.5 hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-400 dark:hover:text-indigo-300"
            >
              {t}
            </button>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------- engine rail -- */}
      <section className="relative z-10 mx-auto max-w-5xl px-5 pt-6">
        <div className="no-scrollbar flex snap-x gap-2 overflow-x-auto pb-2">
          {RAIL.map((id) => {
            const e = engines.find((x) => x.id === id);
            if (!e) return null;
            const active = e.id === engine.id;
            return (
              <button
                key={id}
                onClick={() => {
                  setEngineId(e.id);
                  setFocusKey((k) => k + 1);
                }}
                className={cn(
                  "flex shrink-0 snap-start items-center gap-2 rounded-2xl border px-3.5 py-2.5 text-sm font-medium transition-all duration-200",
                  active
                    ? cn("border-transparent bg-gradient-to-r text-white shadow-lg", e.accent)
                    : "border-slate-200/80 bg-white/55 text-slate-600 hover:-translate-y-0.5 hover:border-indigo-300 dark:border-white/10 dark:bg-white/5 dark:text-slate-300",
                )}
              >
                <span
                  className={cn(
                    "grid h-6 w-6 place-items-center rounded-lg text-[11px] font-bold",
                    active ? "bg-white/25 text-white" : cn("bg-gradient-to-br text-white", e.accent),
                  )}
                >
                  {e.icon}
                </span>
                {e.name}
              </button>
            );
          })}
        </div>
      </section>

      {/* -------------------------------------------------------- content -- */}
      <main className="relative z-10 mx-auto max-w-6xl px-5 pb-24">
        <div className="mt-10 mb-8 flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/70 pb-4 dark:border-white/10">
          <nav className="flex flex-wrap gap-1.5">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition",
                  tab === t.id
                    ? "bg-slate-900 text-white shadow-lg shadow-slate-900/15 dark:bg-white dark:text-slate-900"
                    : "text-slate-500 hover:bg-slate-900/5 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-white",
                )}
              >
                <span className="text-[13px]">{t.icon}</span>
                {t.label}
                {t.id === "history" && history.length > 0 && (
                  <span className="rounded-full bg-slate-500/15 px-1.5 text-[10px]">{history.length}</span>
                )}
              </button>
            ))}
          </nav>

          {tab === "results" && (
            <div className="flex flex-wrap items-center gap-2">
              <div className="mr-1 flex gap-0.5 rounded-full bg-slate-900/5 p-0.5 dark:bg-white/10">
                {(["web", "image"] as ResultFilters["mode"][]).map((m) => (
                  <button
                    key={m}
                    onClick={() => setMode(m)}
                    className={cn(
                      "rounded-full px-3 py-1.5 text-xs font-medium transition",
                      mode === m
                        ? "bg-white text-slate-900 shadow-sm dark:bg-white/20 dark:text-white"
                        : "text-slate-500 dark:text-slate-400",
                    )}
                  >
                    {m === "web" ? "Web" : "Images"}
                  </button>
                ))}
              </div>
              {(["", "d1", "d7", "m1"] as ResultFilters["dateRestrict"][]).map((d) => (
                <button
                  key={d}
                  onClick={() => setPrefs({ ...prefs, dateRestrict: d })}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-xs font-medium transition",
                    prefs.dateRestrict === d
                      ? "bg-indigo-500 text-white"
                      : "bg-slate-900/5 text-slate-500 hover:bg-slate-900/10 dark:bg-white/10 dark:text-slate-400",
                  )}
                >
                  {d === "" ? "Any time" : d === "d1" ? "24h" : d === "d7" ? "Week" : "Month"}
                </button>
              ))}
              <button
                onClick={() => setPrefs({ ...prefs, safe: !prefs.safe })}
                className={cn(
                  "rounded-full px-3 py-1.5 text-xs font-medium transition",
                  prefs.safe
                    ? "bg-emerald-500 text-white"
                    : "bg-slate-900/5 text-slate-500 dark:bg-white/10 dark:text-slate-400",
                )}
              >
                SafeSearch {prefs.safe ? "on" : "off"}
              </button>
            </div>
          )}
        </div>

        {/* search operators */}
        {tab === "results" && googleConnected && (
          <div className="mb-7 flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-semibold tracking-wider text-slate-400 uppercase">Operators</span>
            {OPERATORS.map((op) => (
              <button
                key={op.label}
                title={op.note}
                onClick={() => {
                  const next = op.apply(query.trim() || "react hooks");
                  setQuery(next);
                  setFocusKey((k) => k + 1);
                }}
                className="rounded-full border border-slate-200/80 bg-white/60 px-3 py-1.5 font-mono text-[11.5px] text-slate-600 transition hover:-translate-y-0.5 hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:text-indigo-300"
              >
                {op.label}
              </button>
            ))}
          </div>
        )}

        <div key={tab + mode} className="animate-rise">
          {tab === "results" && (
            <ResultsPanel
              query={query}
              config={config}
              filters={filters}
              onOpenSettings={() => setSettingsOpen(true)}
              onNotify={push}
              onWebSearch={(q) => launch(buildUrl(ENGINES[0], q), true)}
            />
          )}
          {tab === "everywhere" && (
            <EverywherePanel
              query={query}
              engines={engines}
              selected={selected}
              onToggle={setSelected}
              onRun={(q, e) => submit(q, e, { forceNewTab: true })}
              onNotify={push}
            />
          )}
          {tab === "links" && <QuickLinks links={links} onChange={setLinks} onNotify={push} />}
          {tab === "history" && (
            <HistoryPanel
              history={history}
              engines={engines}
              onRerun={(q, id) => {
                const e = engines.find((x) => x.id === id) ?? ENGINES[0];
                setEngineId(e.id);
                setQuery(q);
                submit(q, e);
              }}
              onRemove={(q) => setHistory((prev) => prev.filter((h) => h.q !== q))}
              onClear={() => {
                setHistory([]);
                push("History cleared");
              }}
            />
          )}
        </div>
      </main>

      {/* --------------------------------------------------------- footer -- */}
      <footer className="relative z-10 border-t border-slate-200/70 py-8 dark:border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-5 text-center sm:flex-row sm:justify-between sm:text-left">
          <div className="flex items-center gap-2.5">
            <LogoMark className="h-7 w-7 rounded-lg" />
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Nexus · powered by the Google Custom Search JSON API
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
            <span>
              <kbd className="rounded border border-slate-300 px-1.5 py-0.5 dark:border-white/15">/</kbd> focus
            </span>
            <span>
              <kbd className="rounded border border-slate-300 px-1.5 py-0.5 dark:border-white/15">⌘K</kbd> search
            </span>
            <span>
              <kbd className="rounded border border-slate-300 px-1.5 py-0.5 dark:border-white/15">⌘,</kbd> settings
            </span>
            <button onClick={() => setSettingsOpen(true)} className="text-indigo-500 hover:underline">
              Connect Google
            </button>
          </div>
        </div>
      </footer>

      {/* --------------------------------------------------------- toasts -- */}
      <div className="pointer-events-none fixed bottom-5 left-1/2 z-50 flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-2 px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              "animate-pop pointer-events-auto w-full rounded-2xl px-4 py-3 text-center text-sm shadow-2xl backdrop-blur-xl",
              t.tone === "error"
                ? "bg-rose-500/95 text-white"
                : t.tone === "success"
                  ? "bg-emerald-500/95 text-white"
                  : "bg-slate-900/92 text-white dark:bg-white/95 dark:text-slate-900",
            )}
          >
            {t.text}
          </div>
        ))}
      </div>

      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        config={config}
        onConfigChange={setConfig}
        customEngines={customEngines}
        onCustomEnginesChange={setCustomEngines}
        prefs={prefs}
        onPrefsChange={setPrefs}
        onNotify={push}
      />
    </div>
  );
}
